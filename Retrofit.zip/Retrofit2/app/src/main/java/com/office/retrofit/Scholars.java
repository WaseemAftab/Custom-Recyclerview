package com.office.retrofit;

import java.util.List;

import retrofit2.Call;

public class Scholars {

   public List<Scholar> scholoars;


}
