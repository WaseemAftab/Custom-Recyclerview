package com.office.retrofit;

import java.util.List;

import retrofit2.Call;

public class Scholar {
    public String id,name;
    public int age;
    public List<Model> surah;

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSurah(List<Model> surah) {
        this.surah = surah;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

}
