package com.office.retrofit;

public class Model {
    private String name_eng;
    private String name_ar;
    private String total_ayat;

    public String getName_eng() {
        return name_eng;
    }

    public String getName_ar() {
        return name_ar;
    }

    public String getTotal_ayat() {
        return total_ayat;
    }
}
