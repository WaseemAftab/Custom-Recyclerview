package com.office.retrofit;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JsonPlaceHolderApi {

    String BASE_URL = "http://www.bhimsoft.com/";
    //http://www.bhimsoft.com/alquran/data/quran.json;

    @GET("alquran/data/quran.json")
    Call<Scholars> getScolars();
}
