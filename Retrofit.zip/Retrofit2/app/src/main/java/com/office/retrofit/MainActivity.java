package com.office.retrofit;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView textViewresult;

    private RecyclerAdapter recyclerAdapter;
    private RecyclerView recyclerView;

    private JsonPlaceHolderApi jsonPlaceHolderApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);


        textViewresult = (TextView) findViewById(R.id.txtview);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(JsonPlaceHolderApi.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
//        getScholars();
    }

    private void getScholars() {
        Call<Scholars> call = jsonPlaceHolderApi.getScolars();


        call.enqueue(new Callback<Scholars>() {
            @Override
            public void onResponse(Call<Scholars> call, Response<Scholars> response) {

                if (!response.isSuccessful()) {
                    textViewresult.setText("code: " + response.code());
                    return;
                }if (response.body() != null) {
                    Log.i("onSuccess", response.body().toString());

                        String jsonresponse = response.body().toString();
                        writeRecycler(jsonresponse);

                    } else {
                        Log.i("onEmptyResponse", "Returned empty response");//Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }


            @Override
            public void onFailure(Call<Scholars> call, Throwable t) {

                textViewresult.setText(t.getMessage());

            }
        });


    }

    private void writeRecycler(String responce) {

        try {
            //getting the whole json object from the response
            JSONObject obj = new JSONObject(responce);
            if (obj.optString("status").equals("true")) {

                ArrayList<Scholar> modelRecyclerArrayList = new ArrayList<>();
                JSONArray dataArray = obj.getJSONArray("data");

                for (int i = 0; i < dataArray.length(); i++) {

                    Scholar modelRecycler = new Scholar();
                    JSONObject dataobj = dataArray.getJSONObject(i);

                    modelRecycler.setName(dataobj.getString("name"));
                    modelRecycler.setAge(dataobj.getInt("country"));


                    modelRecyclerArrayList.add(modelRecycler);

                }

                recyclerAdapter = new RecyclerAdapter(this, modelRecyclerArrayList);
                recyclerView.setAdapter(recyclerAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));

            } else {
                Toast.makeText(MainActivity.this, obj.optString("message") + "", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}


